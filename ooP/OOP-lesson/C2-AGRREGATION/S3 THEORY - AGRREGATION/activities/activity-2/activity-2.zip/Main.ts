import { House } from "./House";
import { Door } from "./Door";
import { Room } from "./Room";

// TODO  :
//  1- Create:
//      - 1 house
//        - 3 doors
//         - 2 rooms

// 2- Add the 2 rooms to the house

// 3 – Add a door to the house and rooms
