export class House {
  name: string;

  constructor(name: string) {
    this.name = name;
  }
}
