function sayManyTimes(name, count) {
  for (let i = 0; i < count; i += 1) {
    console.log(`${name}!`);
  }
}

// Say  'Muriel!' six times
sayManyTimes("Muriel",6);


