let phoneNumber;

if (Math.random() > 0.5) {
  phoneNumber = "ronan";
} else {
  phoneNumber = 7167762323;
}

